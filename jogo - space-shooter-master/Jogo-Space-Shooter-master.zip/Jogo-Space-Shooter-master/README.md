# Jogo-Space-Shooter DIO
Jogo Space Shooter utilizando HTML, CSS e Javascript e posicionamento no CSS e lógica de programação utilizando posicionamento com CSS, manipulação do DOM, eventListeners, e manipulação de Array.
